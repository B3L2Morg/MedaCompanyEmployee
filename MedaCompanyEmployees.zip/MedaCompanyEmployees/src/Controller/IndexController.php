<?php

namespace App\Controller;

use App\Entity\MedaEmployees;
use App\Entity\MedaUsers;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/")
 */
class IndexController extends AbstractController
{
    /**
     * @Route("/", name="index", methods={"GET"})
     */
    public function index(UserPasswordHasherInterface $passwordHasher, EntityManagerInterface $entityManager): Response
    {
        // ... e.g. get the user data from a registration form
        $user = new MedaUsers();
        $plaintextPassword = 'test';

        $medaEmployees = $entityManager
            ->getRepository(MedaEmployees::class)
            ->findAll();
        foreach ($medaEmployees as $medaEmployee) {
            var_dump($medaEmployee);
        }
        die();

        // hash the password (based on the security.yaml config for the $user class)
        $hashedPassword = $passwordHasher->hashPassword(
            $user,
            $plaintextPassword
        );
        var_dump($hashedPassword);
        die();
        $user->setPassword($hashedPassword);

        return $this->render('index.html.twig');
    }

    /**
     * @Route("/submit", name="submit", methods={"GET"})
     */
    public function submit(EntityManagerInterface $entityManager): Response
    {
        $medaEmployeesData = $entityManager
            ->getRepository(MedaEmployees::class)
            ->createQueryBuilder('employee')
            ->andWhere('employee.username = :val')
            ->setParameter()
            ->findAll();

        return $this->render('login.html.twig');
    }
}