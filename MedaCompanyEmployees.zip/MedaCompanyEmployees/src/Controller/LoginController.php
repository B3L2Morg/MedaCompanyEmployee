<?php

namespace App\Controller;

use App\Entity\MedaEmployees;
use App\Entity\MedaUsers;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class LoginController extends AbstractController
{
    /**
     * @Route("/login", name="app_login")
     */
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
        // if ($this->getUser()) {
        //     return $this->redirectToRoute('target_path');
        // }

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render('security/login.html.twig', ['last_username' => $lastUsername, 'error' => $error]);
    }

    /**
     * @Route("/auth", name="app_auth")
     */
    public function authentic(UserPasswordHasherInterface $passwordHasher, EntityManagerInterface $entityManager, Request $request): Response
    {
        $username = $request->get('username');
        $access = $request->get('password');
        $medaUsers = $entityManager
            ->getRepository(MedaUsers::class)
            ->findAll();
        $userFound = false;
        $hashedPassword = false;
        foreach ($medaUsers as $medaUser) {
            if ($medaUser->getUsername() == $username) {
                $userFound = true;
            }
            $hashedPassword = $passwordHasher->isPasswordValid(
                $medaUser,
                $access
            );
        }

        if (!$userFound && !$hashedPassword) {
            return $this->redirect('login');
        }

        return $this->redirect('meda/employees');
    }

    /**
     * @Route("/logout", name="app_logout")
     */
    public function logout(): void
    {
        throw new \LogicException('This method can be blank - it will be intercepted by the logout key on your firewall.');
    }
}
