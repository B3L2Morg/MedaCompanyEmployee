<?php

namespace App\Controller;

use App\Entity\MedaEmployees;
use App\Form\MedaEmployeesType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/meda/employees")
 */
class MedaEmployeesController extends AbstractController
{
    /**
     * @Route("/", name="app_meda_employees_index", methods={"GET"})
     */
    public function index(EntityManagerInterface $entityManager): Response
    {
        $medaEmployees = $entityManager
            ->getRepository(MedaEmployees::class)
            ->findAll();

        return $this->render('meda_employees/index.html.twig', [
            'meda_employees' => $medaEmployees,
        ]);
    }

    /**
     * @Route("/new", name="app_meda_employees_new", methods={"GET", "POST"})
     */
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $medaEmployee = new MedaEmployees();
        $form = $this->createForm(MedaEmployeesType::class, $medaEmployee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($medaEmployee);
            $entityManager->flush();

            return $this->redirectToRoute('app_meda_employees_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('meda_employees/new.html.twig', [
            'meda_employee' => $medaEmployee,
            'form' => $form,
        ]);
    }

    /**
     * @Route("/{idEmployee}", name="app_meda_employees_show", methods={"GET"})
     */
    public function show(MedaEmployees $medaEmployee): Response
    {
        return $this->render('meda_employees/show.html.twig', [
            'meda_employee' => $medaEmployee,
        ]);
    }

    /**
     * @Route("/{idEmployee}/edit", name="app_meda_employees_edit", methods={"GET", "POST"})
     */
    public function edit(Request $request, MedaEmployees $medaEmployee, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(MedaEmployeesType::class, $medaEmployee);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_meda_employees_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->renderForm('meda_employees/edit.html.twig', [
            'meda_employee' => $medaEmployee,
            'form' => $form,
        ]);
    }

    /**
     * @Route("/{idEmployee}", name="app_meda_employees_delete", methods={"POST"})
     */
    public function delete(Request $request, MedaEmployees $medaEmployee, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$medaEmployee->getIdEmployee(), $request->request->get('_token'))) {
            $entityManager->remove($medaEmployee);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_meda_employees_index', [], Response::HTTP_SEE_OTHER);
    }
}
